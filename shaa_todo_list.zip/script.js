const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');

function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText === "") return;

    const li = document.createElement('li');
    li.innerHTML = `
        <span>${taskText}</span>
        <div class="actions">
            <button onclick="markDone(this)">✔</button>
            <button onclick="deleteTask(this)">🗑</button>
        </div>
    `;

    taskList.appendChild(li);
    saveTasks();
    taskInput.value = "";
}

function markDone(btn) {
    btn.closest('li').classList.toggle('done');
    saveTasks();
}

function deleteTask(btn) {
    btn.closest('li').remove();
    saveTasks();
}

function saveTasks() {
    localStorage.setItem('shaa_tasks', taskList.innerHTML);
}

function loadTasks() {
    taskList.innerHTML = localStorage.getItem('shaa_tasks') || "";
}

window.onload = loadTasks;
