# Shaa's To-Do List App

This is a simple to-do list web application created using HTML, CSS, and JavaScript.

## Features
- Add, mark as done, and delete tasks
- Tasks persist using browser's localStorage
- Responsive design for mobile and desktop
- Clean UI with hover effects

## How to Run
Open `index.html` in your browser, or use Live Server in VS Code for live preview.

## Screenshot
![Screenshot](screenshot.png)
